<?php

include_once EINAR_CORE_INC_PATH . '/title/helper.php';
include_once EINAR_CORE_INC_PATH . '/title/class-einarcore-title.php';
include_once EINAR_CORE_INC_PATH . '/title/class-einarcore-titles.php';
