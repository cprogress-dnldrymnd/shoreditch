<?php

include_once EINAR_CORE_INC_PATH . '/title/layouts/standard/helper.php';
include_once EINAR_CORE_INC_PATH . '/title/layouts/standard/class-einarcore-standard-title.php';
include_once EINAR_CORE_INC_PATH . '/title/layouts/standard/dashboard/meta-box/standard-title-meta-box.php';
