<?php

include_once EINAR_CORE_INC_PATH . '/title/layouts/breadcrumbs/helper.php';
include_once EINAR_CORE_INC_PATH . '/title/layouts/breadcrumbs/class-einarcore-breadcrumbs-title.php';
