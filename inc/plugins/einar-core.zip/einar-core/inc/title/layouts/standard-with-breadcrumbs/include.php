<?php

include_once EINAR_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/helper.php';
include_once EINAR_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/class-einarcore-standard-with-breadcrumbs-title.php';
