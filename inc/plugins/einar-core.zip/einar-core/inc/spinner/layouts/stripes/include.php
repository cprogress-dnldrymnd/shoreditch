<?php

include_once EINAR_CORE_INC_PATH . '/spinner/layouts/stripes/helper.php';
