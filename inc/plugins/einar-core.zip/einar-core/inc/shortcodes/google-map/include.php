<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/google-map/class-einarcore-google-map-shortcode.php';
