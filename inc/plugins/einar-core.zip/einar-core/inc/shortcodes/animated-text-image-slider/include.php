<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/animated-text-image-slider/class-einarcore-animated-text-image-slider.php';