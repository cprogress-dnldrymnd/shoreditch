<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/author-info/widget/class-einarcore-author-info-widget.php';
