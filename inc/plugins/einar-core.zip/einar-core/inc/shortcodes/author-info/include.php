<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/author-info/class-einarcore-author-info-shortcode.php';
