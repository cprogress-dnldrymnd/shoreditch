<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/swapping-image-gallery/class-einarcore-swapping-image-gallery-shortcode.php';
