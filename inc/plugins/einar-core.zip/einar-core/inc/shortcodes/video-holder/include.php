<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/video-holder/class-einarcore-video-holder-shortcode.php';