<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php einar_core_template_part( 'shortcodes/video-holder', 'templates/parts/video', '', $params ) ?>
</div>