<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/icon-list-item/widget/class-einarcore-icon-list-item-widget.php';
