<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/icon-list-item/class-einarcore-icon-list-item-shortcode.php';
