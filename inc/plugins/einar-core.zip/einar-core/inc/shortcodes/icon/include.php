<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/icon/class-einarcore-icon-shortcode.php';
