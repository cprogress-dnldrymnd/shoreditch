<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/icon/widget/class-einarcore-icon-widget.php';
