<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/custom-font/widget/class-einarcore-custom-font-widget.php';
