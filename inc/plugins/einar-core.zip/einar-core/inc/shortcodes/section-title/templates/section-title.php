<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php einar_core_template_part( 'shortcodes/section-title', 'templates/parts/title', '', $params ); ?>
	<?php einar_core_template_part( 'shortcodes/section-title', 'templates/parts/text', '', $params ); ?>
	<?php einar_core_template_part( 'shortcodes/section-title', 'templates/parts/button', '', $params ); ?>
</div>
