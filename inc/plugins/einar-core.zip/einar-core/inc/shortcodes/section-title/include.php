<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/section-title/class-einarcore-section-title-shortcode.php';
