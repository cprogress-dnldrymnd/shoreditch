<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/helper.php';
include_once EINAR_CORE_SHORTCODES_PATH . '/class-einarcore-shortcodes.php';
