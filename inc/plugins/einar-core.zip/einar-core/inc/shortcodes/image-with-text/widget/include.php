<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/image-with-text/widget/class-einarcore-image-with-text-widget.php';
