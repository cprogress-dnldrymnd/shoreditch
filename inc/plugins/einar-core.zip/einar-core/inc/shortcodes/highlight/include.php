<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/highlight/class-einarcore-highlight-shortcode.php';
