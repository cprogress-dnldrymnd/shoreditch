<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/interactive-banners/interactive-banners.php';
