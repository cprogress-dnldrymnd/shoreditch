<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/dropcaps/class-einarcore-dropcaps-shortcode.php';
