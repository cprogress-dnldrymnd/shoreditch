<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/image-gallery/class-einarcore-image-gallery-shortcode.php';
