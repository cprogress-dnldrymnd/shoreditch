<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/single-image/widget/class-einarcore-single-image-widget.php';
