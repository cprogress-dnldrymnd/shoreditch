<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/separator/class-einarcore-separator-shortcode.php';
