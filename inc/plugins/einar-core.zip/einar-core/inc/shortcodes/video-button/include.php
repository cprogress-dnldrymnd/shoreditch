<?php

include_once EINAR_CORE_SHORTCODES_PATH . '/video-button/class-einarcore-video-button-shortcode.php';
