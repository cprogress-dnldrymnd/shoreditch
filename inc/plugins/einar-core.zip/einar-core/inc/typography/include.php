<?php

include_once EINAR_CORE_INC_PATH . '/typography/helper.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/typography-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h1-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h2-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h3-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h4-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h5-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/h6-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/link-options.php';
include_once EINAR_CORE_INC_PATH . '/typography/dashboard/admin/p-options.php';
