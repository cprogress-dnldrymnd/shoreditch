<?php

include_once EINAR_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';
