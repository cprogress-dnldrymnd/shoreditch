<?php

include_once EINAR_CORE_INC_PATH . '/header/helper.php';
include_once EINAR_CORE_INC_PATH . '/header/class-einarcore-header.php';
include_once EINAR_CORE_INC_PATH . '/header/class-einarcore-headers.php';
include_once EINAR_CORE_INC_PATH . '/header/template-functions.php';
