<?php

get_header();

// Include cpt content template
einar_core_template_part( 'post-types/team', 'templates/content' );

get_footer();
