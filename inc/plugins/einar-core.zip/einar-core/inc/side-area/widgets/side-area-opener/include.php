<?php

include_once EINAR_CORE_INC_PATH . '/side-area/widgets/side-area-opener/class-einarcore-side-area-opener-widget.php';
