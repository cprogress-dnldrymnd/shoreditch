<?php

include_once EINAR_CORE_PLUGINS_PATH . '/contact-form-7/class-einarcore-contact-form-7.php';
