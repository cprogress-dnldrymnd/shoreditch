<?php

include_once EINAR_CORE_PLUGINS_PATH . '/twitter/helper.php';
