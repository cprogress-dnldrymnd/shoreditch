<?php

include_once EINAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-einarcore-blog-list-widget.php';
include_once EINAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-einarcore-simple-blog-list-widget.php';
