<?php

include_once EINAR_CORE_INC_PATH . '/roles/helper.php';
include_once EINAR_CORE_INC_PATH . '/roles/administrator/helper.php';
