<?php

include_once EINAR_CORE_INC_PATH . '/widgets/svg-icon/class-einarcore-svg-icon-widget.php';
