<?php

include_once EINAR_CORE_INC_PATH . '/widgets/sticky-sidebar/class-einarcore-sticky-sidebar-widget.php';
