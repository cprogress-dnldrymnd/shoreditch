<?php

include_once EINAR_CORE_INC_PATH . '/widgets/banner/class-einarcore-banner-widget.php';
