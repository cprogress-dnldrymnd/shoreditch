<?php

include EINAR_CORE_INC_PATH . '/widgets/contact-info/class-einarcore-contact-info-widget.php';
