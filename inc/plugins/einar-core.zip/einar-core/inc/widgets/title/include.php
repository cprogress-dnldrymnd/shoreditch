<?php

include_once EINAR_CORE_INC_PATH . '/widgets/title/class-einarcore-title-widget.php';
