<?php

include_once EINAR_CORE_INC_PATH . '/search/widgets/search-opener/class-einarcore-search-opener.php';
