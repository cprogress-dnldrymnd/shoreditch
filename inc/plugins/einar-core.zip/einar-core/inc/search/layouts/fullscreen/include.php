<?php

include_once EINAR_CORE_INC_PATH . '/search/layouts/fullscreen/helper.php';
include_once EINAR_CORE_INC_PATH . '/search/layouts/fullscreen/class-einarcore-fullscreen-search.php';
