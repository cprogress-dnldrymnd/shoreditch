<?php

include_once EINAR_CORE_INC_PATH . '/search/layouts/covers-header/helper.php';
include_once EINAR_CORE_INC_PATH . '/search/layouts/covers-header/class-einarcore-covers-header-search.php';
