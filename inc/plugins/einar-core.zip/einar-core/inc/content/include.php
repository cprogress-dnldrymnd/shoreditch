<?php

include_once EINAR_CORE_INC_PATH . '/content/helper.php';
